<?php
require 'connect.php';

// Insert data
$sql2 = "INSERT INTO Dosen (KD_DOSEN, NAMA_DOSEN, ALAMAT)
VALUES  ('040001', 'EKO PURWANTO, M.Kom', 'SUKOHARJO'),
        ('040002','FAULINDA ELY NASTITI, M.Eng','SUKOHARJO'),
        ('040003','JONI MAULINDAR, M.Eng','SURAKARTA'),
        ('040024','SRI SUMARLINDA, M.Kom','YOGYAKARTA'),
        ('040015','JAMES BOND, M.T','YOGYAKARTA'),
        ('040006','EGI SUMINAR, MBA','BANDUNG')";

if ($conn->query($sql2) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
?> 