<?php
require 'connect.php';

// Insert data
$sql2 = "INSERT INTO Matkul (KD_MATKUL, NAMA_MATKUL, SKS)
VALUES  ('04211','SISTEM INFORMASI AKUNTANSI','3'),
        ('04212','REKAYASA PERANGKAT LUNAK','3'),
        ('04213','BASIS DATA','2'),
        ('04311','MATEMATIKA BISNIS','3'),
        ('04312','PENGANTAR TEKNOLOGI','2'),
        ('04411','ANALISA LAPORAN KEUANGAN','2')";

if ($conn->query($sql2) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
?> 