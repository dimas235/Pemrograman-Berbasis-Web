<?php
require 'connect.php';

// sql to create table
$sql = "CREATE TABLE Matkul (
KD_MATKUL VARCHAR(5) PRIMARY KEY,
NAMA_MATKUL VARCHAR(25) NOT NULL,
SKS VARCHAR(1) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
  echo "Table Matkul created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?> 