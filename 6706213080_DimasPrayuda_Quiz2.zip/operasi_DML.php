<?php include("connect.php");?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>

<body>
    <h2>Tampilah semua tabel yang telah dibuat dan diisi data masing-masing</h2>
    <div class="result">
    <?php
        $sql = "SELECT NIM, NamaMHS, ALAMAT, TELP FROM mahasiswa";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "NIM: " . $row["NIM"]. " - NamaMHS: " . $row["NamaMHS"]. " - ALAMAT: " . $row["ALAMAT"].  " - TELP: " .$row["TELP"]."<br>";
        }
        } else {
        echo "0 results";
        }
    ?>

    <?php
        $sql = "SELECT KD_PRODI, NAMA_PRODI FROM PRODI";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
        echo "<br>";
        while($row = $result->fetch_assoc()) {
            echo "KD_PRODI: " . $row["KD_PRODI"]. " - NAMA_PRODI: " . $row["NAMA_PRODI"]. "<br>";
        }
        } else {
        echo "0 results";
        }
    ?>
    <?php
        $sql = "SELECT KD_DOSEN, NAMA_DOSEN, ALAMAT FROM dosen";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
        echo "<br>";
        while($row = $result->fetch_assoc()) {
            echo "KD_DOSEN: " . $row["KD_DOSEN"]. " - NAMA_DOSEN: " . $row["NAMA_DOSEN"]. " - ALAMAT: " . $row["ALAMAT"]. "<br>";
        }
        } else {
        echo "0 results";
        }
    ?>
    <?php
        $sql = "SELECT KD_MATKUL, NAMA_MATKUL, SKS FROM matkul";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        // output data of each row
        echo "<br>";
        while($row = $result->fetch_assoc()) {
            echo "KD_MATKUL: " . $row["KD_MATKUL"]. " - NAMA_MATKUL: " . $row["NAMA_MATKUL"]. " - SKS: " . $row["SKS"]. "<br>";
        }
        } else {
        echo "0 results";
        }
    ?>
    </div>
    <h2>DOSEN YANG BERASAL DARI YOGYAKARTA</h2>
    <div class="result">
    <?php
    $sql = "SELECT*FROM dosen WHERE ALAMAT = 'YOGYAKARTA'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<b>NAMA DOSEN : </b>" . $row["NAMA_DOSEN"] ."<br>";
                }
            } else {
                echo "0 data";
            }
    ?>
    </div>
    <h2>MAHASISWA YANG BERASAL DARI SURAKARTA</h2>
    <div class="result">
    <?php
    $sql = "SELECT*FROM mahasiswa WHERE ALAMAT = 'SURAKARTA' ORDER BY NamaMHS ASC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<b>NAMA MAHASISWA : </b>" . $row["NamaMHS"] . "<br>";
                }
            } else {
                echo "0 data";
            }
    ?>
    </div>
    <h2>NAMA MATA KULIAH YANG MEMILIKI SKS = 3</h2>
    <div class="result">
    <?php
    $sql = "SELECT*FROM matkul WHERE SKS = '3'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<b>NAMA MATA KULIAH :</b> " . $row["NAMA_MATKUL"] . "<br>";
                }
            } else {
                echo "0 data";
            }
    ?>
    </div>            
</body>

</html>