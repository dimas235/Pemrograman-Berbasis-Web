<?php
require 'connect.php';

// sql to create table
$sql = "CREATE TABLE Prodi (
KD_PRODI INT(2) AUTO_INCREMENT PRIMARY KEY,
NAMA_PRODI VARCHAR(25) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
  echo "Table Prodi created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

// Insert data
$sql2 = "INSERT INTO Prodi (KD_PRODI, NAMA_PRODI)
VALUES  ('','SISTEM INFORMASI'),
        ('','MANAJEMEN INFORMATIKA'),
        ('','TEKNIK INFORMATIKA'),
        ('','TEKNIK KOMPUTER')";

if ($conn->query($sql2) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
?> 