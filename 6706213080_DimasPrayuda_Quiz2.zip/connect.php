<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "kuliah";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
  die("Tidak dapat terhubung ke database");
}
echo "Koneksi berhasil";

?>