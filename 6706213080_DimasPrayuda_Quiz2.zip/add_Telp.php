<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "kuliah";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Tidak bisa  terkoneksi ke database ");
} /*else {
    echo "OK";
}*/
$renameTelp = "ALTER TABLE dosen ADD NO_TELP VARCHAR(12) NOT NULL
VALUE (";
$sql = mysqli_query($koneksi, $renameTelp);
if($sql === true){
    echo "BERHASIL MENAMBAHKAN FIELD NO_TELP PADA TABEL DOSEN";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            padding-top: 10px;
            padding-left: 20px;
            padding-right: 20px;
            width: 80%;
        }

    </style>
</head>
</html>
