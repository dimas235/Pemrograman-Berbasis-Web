<?php
require 'connect.php';

// Insert data
$sql2 = "INSERT INTO Mahasiswa (NIM, NAMA, ALAMAT, TELP)
VALUES  ('044010101','WAHYUDIN','SOLO','081905878712'),
        ('044010102','SRIYONO','KLATEN','089088767677'),
        ('044020203','RUSTANTO','SUKOHARJO','082123878727'),
        ('044010304','MARIYATUN','WONOGIRI','081389698889'),
        ('044020205','SRI HANDAYANI','BANDUNG','081289787890'),
        ('044020406','HERDIYANI','KLATEN','081789773262'),
        ('044020407','SRI MARIYATUN','SURAKARTA','086778687889'),
        ('044010308','EKO WAHYUDI','SURAKARTA','081363902840')";

if ($conn->query($sql2) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
?> 