<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "kuliah";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Tidak bisa  terkoneksi ke database ");
} /*else {
    echo "OK";
}*/
$renameName = "ALTER TABLE mahasiswa CHANGE NAMA NamaMHS VARCHAR(26) NOT NULL";
$sql = mysqli_query($koneksi, $renameName);
if($sql === true){
    echo "BERHASIL RENAME NAMA MENJADI NamaMHS PADA TABEL MAHASISWA";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            padding-top: 10px;
            padding-left: 20px;
            padding-right: 20px;
            width: 70%;
        }

    </style>
</head>
</html>