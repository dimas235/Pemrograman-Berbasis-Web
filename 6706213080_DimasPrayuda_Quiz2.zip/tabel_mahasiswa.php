<?php
require 'connect.php';

// sql to create table
$sql = "CREATE TABLE Mahasiswa (
NIM VARCHAR(9) PRIMARY KEY,
NAMA VARCHAR(25) NOT NULL,
ALAMAT VARCHAR(30) NOT NULL,
TELP VARCHAR(12) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
  echo "Table Mahasiswa created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?> 