<?php
require 'connect.php';

// sql to create table
$sql = "CREATE TABLE Dosen (
KD_DOSEN VARCHAR(6) PRIMARY KEY,
NAMA_DOSEN VARCHAR(40) NOT NULL,
ALAMAT VARCHAR(40) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
  echo "Table Dosen created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?> 