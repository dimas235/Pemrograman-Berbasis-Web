<html>
<body>
    <form action="#" method="post">
    <input type="text" name="nama" placeholder="Nama Kita"></input><br/>
    <input type="text" name="alamat" placeholder="Alamat Kita"></input><br/>
    <input type="submit" name="submit" value="Submit"></input>
    </form>

    <?php
    if( $_POST["nama"] || $_POST["alamat"])
    {
    echo "Halo: ". $_POST['nama']. "<br />";
    echo "Alamat Anda: ". $_POST["alamat"]. "<br />";
    }
    ?>
    
</body>
</html>